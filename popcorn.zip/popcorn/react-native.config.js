module.exports = {
  assets: [
    // TODO: link documentation about fonts to this section
    // If you need to add non-google fonts (those not available through the `@expo-google-fonts/**`
    // packages, you can add them to the referenced path below and uncomment this line.
    // "./assets/fonts/"
  ],
}
