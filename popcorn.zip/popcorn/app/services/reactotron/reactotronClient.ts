/**
 * This file is loaded in React Native and exports the RN version
 * of Reactotron's client.
 *
 * Web is loaded from reactotronClient.web.ts.
 */
import Reactotron from "reactotron-react-native"
export { Reactotron }
