/**
 * This file is loaded in web and exports the React.js version
 * of Reactotron's client.
 *
 * React Native is loaded from reactotronClient.ts.
 */
import Reactotron from "reactotron-react-js"
export { Reactotron }
